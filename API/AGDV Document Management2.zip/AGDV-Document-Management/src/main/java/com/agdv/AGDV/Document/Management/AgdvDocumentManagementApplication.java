package com.agdv.AGDV.Document.Management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgdvDocumentManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgdvDocumentManagementApplication.class, args);
	}

}
